package com.galaxyvideoultra

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var title: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(12, 10, 22)
        window.navigationBarColor = android.graphics.Color.rgb(12, 10, 22)
        buildScreen()
        handleIncomingVideo(intent)
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18)
            setBackgroundColor(android.graphics.Color.rgb(12, 10, 22))
        }
        val brand = TextView(this).apply {
            text = "✦  GALAXY VIDEO ULTRA"
            textSize = 20f
            setTextColor(0xFFBBA3FF.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 18, 4, 18)
        }
        title = TextView(this).apply {
            text = "Your personal cinema"
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(4, 12, 4, 12)
        }
        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        val choose = Button(this).apply {
            text = "Choose a video"
            setOnClickListener {
                val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "video/*"
                }
                startActivityForResult(pick, REQUEST_VIDEO)
            }
        }
        val speedLabel = TextView(this).apply {
            text = "Playback speed"
            textSize = 13f
            setTextColor(0xFFD9D2EA.toInt())
            setPadding(4, 12, 4, 2)
        }
        val speeds = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { rate ->
            speeds.addView(Button(this).apply {
                text = "${rate}×"
                textSize = 11f
                setOnClickListener {
                    player?.setPlaybackSpeed(rate)
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        page.addView(brand)
        page.addView(title)
        page.addView(playerView)
        page.addView(choose)
        page.addView(speedLabel)
        page.addView(speeds)
        setContentView(page)
    }

    private fun handleIncomingVideo(intent: Intent?) {
        val uri = intent?.data ?: return
        if (intent.action == Intent.ACTION_VIEW) {
            play(uri)
        }
    }

    private fun play(uri: Uri) {
        if (player == null) {
            player = ExoPlayer.Builder(this).build().also {
                playerView.player = it
                it.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) {
                            title.text = "Now playing"
                        }
                    }
                })
            }
        }
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) { }
        player?.setMediaItem(MediaItem.fromUri(uri))
        player?.prepare()
        player?.playWhenReady = true
        title.text = "Galaxy Video Ultra • Playing"
    }

    @Deprecated("Use Activity Result APIs in a production refinement")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VIDEO && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                play(uri)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        playerView.player = player
    }

    override fun onStop() {
        player?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_VIDEO = 4102
    }
}
