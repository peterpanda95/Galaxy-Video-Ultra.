# Galaxy Video Ultra — Android starter project

Target: Samsung Galaxy A20s (Android 9/10/11 variants; minSdk 23).

## What this starter includes
- Native Android application project (Kotlin).
- Media3 ExoPlayer playback engine.
- Opens video files selected through Android's document picker.
- Declares Android VIEW intent filters for `video/*`, so Android can offer this app as a video-opening choice.
- Basic playback-speed controls and native player transport controls.
- Dark, colourful Galaxy-inspired shell.

## Build an APK
1. Install Android Studio on a Windows, macOS or Linux computer.
2. Open this folder in Android Studio.
3. Allow Gradle to sync and download dependencies.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).
6. Transfer the APK to the Galaxy A20s, open it, and allow installation from that source if Android asks.

## Set as default
After installation, open a video from My Files or Gallery and choose Galaxy Video Ultra. If Android offers **Always**, select it. You can later change defaults under Settings > Apps > Galaxy Video Ultra > Set as default (menu wording varies by One UI version).

## Important limitations
This is a starter native project, not a compiled or tested APK. This environment does not have the Android SDK/Gradle build toolchain, so it cannot compile or verify the APK here. The current starter handles one video at a time and is not yet a complete replacement for every Samsung player feature. Keep Samsung Video Player installed until the APK has been built, installed, and tested with your own videos.

Media3 playback depends on supported codecs and containers. Some MKV/AVI/AC3 combinations may need additional format support.


## Build an APK using only your Android phone (GitHub Actions)

1. Create a new GitHub repository in your mobile browser.
2. Upload the contents of this project ZIP to the repository. Make sure the `.github/workflows/build-apk.yml` file is included.
3. Open the repository's **Actions** tab.
4. Select **Build Galaxy Video Ultra APK**, tap **Run workflow**, then confirm.
5. When the run finishes successfully, open that run and download the **GalaxyVideoUltra-debug-apk** artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then tap it to install. Android may ask you to allow Chrome or your file manager to install unknown apps.

This workflow builds an installable debug APK in GitHub's cloud runner. It does not mean the app has been tested on your phone. Install and test it before changing any default-player settings. Keep Samsung Video Player installed until the replacement is confirmed working.
